"""
NetOps — No AI. User enters device and command; app runs it via SSH and shows raw output.
Same login and credential cache as the main app; no DeepSeek/Claude.
"""

# --- Standard library imports ---
import os        # Used to read environment variables (e.g. FLASK_SECRET_KEY)
import re        # Used to parse device list entries (split on =, :, or whitespace)
import time      # Used to track when credentials were stored, for TTL expiry
import uuid      # Used to generate a unique session ID (conn_id) per browser session
from pathlib import Path          # Used to resolve the base directory for templates
from typing import Optional       # Used for type hints on functions that may return None

# --- Flask web framework imports ---
from flask import Flask, jsonify, redirect, render_template, request, session, url_for
# Flask       — core web application class
# jsonify     — converts Python dicts to JSON HTTP responses for the API endpoints
# redirect    — sends the browser to a different URL (e.g. redirect to login if not authenticated)
# render_template — renders an HTML template file from the template folder
# request     — gives access to incoming HTTP request data (form fields, JSON body)
# session     — server-side session cookie storage (used to persist conn_id across requests)
# url_for     — generates a URL for a named route (avoids hardcoding paths)

# --- Import DeviceSession: the SSH connection wrapper used to talk to network devices ---
import sys
_PARENT = Path(__file__).resolve().parent.parent  # Navigate up two levels to find the parent project
if str(_PARENT) not in sys.path:
    sys.path.insert(0, str(_PARENT))              # Add parent project to Python path so imports work
try:
    from device_session import DeviceSession          # Try importing from parent project directly
except ImportError:
    from automation.device_session import DeviceSession  # Fallback path if project is in 'automation' subpackage

# --- Flask app setup ---
BASE_DIR = Path(__file__).resolve().parent        # Absolute path to the directory this file lives in
app = Flask(__name__, template_folder=str(BASE_DIR))  # Create the Flask app; look for HTML templates in the same folder
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "no-ai-change-me")  # Secret key used to sign session cookies; override in production via env var
app.permanent_session_lifetime = 86400            # Sessions last 24 hours (in seconds) before the browser cookie expires

# --- Credential cache settings ---
CREDENTIAL_CACHE_TTL = 86400    # How long (seconds) credentials stay cached in memory after login — 24 hours
_cred_cache: dict = {}          # In-memory store: maps conn_id -> {username, password, devices, ...}
_active_conns: dict = {}        # In-memory store: maps "conn_id:host" -> active DeviceSession (SSH connection)


# ---------------------------------------------------------------------------
# Session / connection ID helpers
# ---------------------------------------------------------------------------

def _get_conn_id() -> str:
    """
    Returns the unique connection ID for the current browser session.
    Creates and stores a new UUID in the session cookie if one doesn't exist yet.
    This ID is used as the key for the credential cache and active SSH connections.
    """
    if "conn_id" not in session:
        session.permanent = True                   # Mark session as permanent so it respects permanent_session_lifetime
        session["conn_id"] = str(uuid.uuid4())     # Generate a new random unique ID for this browser session
    return session["conn_id"]


# ---------------------------------------------------------------------------
# Credential cache helpers
# ---------------------------------------------------------------------------

def _store_creds(conn_id: str, username: str, password: str,
                 enable_secret: Optional[str], platform: Optional[str], devices: dict) -> None:
    """
    Saves the user's SSH credentials and device list into the in-memory cache.
    Keyed by conn_id so each browser session has its own isolated credential store.
    """
    _cred_cache[conn_id] = {
        "username": username,           # SSH username for authenticating to network devices
        "password": password,           # SSH password
        "enable_secret": enable_secret, # Optional enable/privileged mode password (Cisco etc.)
        "platform": platform,           # Optional Netmiko platform type (e.g. cisco_ios, arista_eos)
        "devices": devices,             # Dict of {NAME: IP} for registered devices (e.g. {"SW1": "10.0.0.1"})
        "stored_at": time.time(),       # Timestamp of when credentials were stored, used to check TTL expiry
    }


def _get_creds(conn_id: str) -> Optional[dict]:
    """
    Retrieves cached credentials for the given conn_id.
    Returns None (and cleans up) if the cache entry has expired past the 24-hour TTL.
    """
    entry = _cred_cache.get(conn_id)   # Look up the cache entry for this session
    if not entry:
        return None                    # No entry found — user has not logged in or cache was cleared
    if (time.time() - entry["stored_at"]) > CREDENTIAL_CACHE_TTL:
        # Credentials have expired — remove them from cache and close any open SSH connections
        del _cred_cache[conn_id]
        for k in list(_active_conns.keys()):
            if k.startswith(conn_id + ":"):        # Find all SSH connections belonging to this session
                try:
                    _active_conns[k].disconnect()  # Gracefully close the SSH connection
                except Exception:
                    pass                           # Ignore errors during disconnect (device may already be gone)
                del _active_conns[k]               # Remove the stale connection from the pool
        return None
    return entry                       # Credentials are valid and within TTL — return them


def _clear_creds(conn_id: str) -> None:
    """
    Removes credentials and closes all SSH connections for a given session.
    Called on logout to ensure clean teardown.
    """
    _cred_cache.pop(conn_id, None)     # Delete credential cache entry (no error if it doesn't exist)
    for k in list(_active_conns.keys()):
        if k.startswith(conn_id + ":"):            # Find all SSH connections for this session
            try:
                _active_conns[k].disconnect()      # Close each SSH connection gracefully
            except Exception:
                pass
            del _active_conns[k]                   # Remove from the active connection pool


# ---------------------------------------------------------------------------
# SSH connection helpers
# ---------------------------------------------------------------------------

def _resolve_host(conn_id: str, device_name: str) -> str:
    """
    Resolves a device name (e.g. 'SW1') to its IP address using the registered device list.
    If the name isn't found in the registered list, it's returned as-is (treated as a direct IP or hostname).
    """
    creds = _get_creds(conn_id)
    if not creds:
        raise RuntimeError("Session expired. Please log in again.")
    devices = creds.get("devices", {})
    for name, ip in devices.items():
        if name.upper() == device_name.upper():    # Case-insensitive name match (SW1 == sw1)
            return ip                              # Return the IP address for this registered device name
    return device_name.strip()                    # Not in the registered list — assume it's a direct IP or hostname


def _get_or_connect(conn_id: str, device_name: str) -> DeviceSession:
    """
    Returns an active SSH session to the target device.
    Reuses an existing connection if one is already open (connection pooling).
    Creates a new SSH connection if none exists yet.
    """
    host = _resolve_host(conn_id, device_name)     # Resolve device name to IP/hostname
    key = f"{conn_id}:{host}"                      # Unique key for this session + device combination
    if key in _active_conns:
        return _active_conns[key]                  # Reuse the existing open SSH connection (avoids reconnecting each command)

    creds = _get_creds(conn_id)
    if not creds:
        raise RuntimeError("Session expired. Please log in again.")

    # Create a new SSH session using the stored credentials
    ds = DeviceSession(
        host=host,
        username=creds["username"],
        password=creds["password"],
        platform=creds.get("platform"),            # Optional: tells Netmiko which CLI dialect to use
        enable_secret=creds.get("enable_secret"),  # Optional: used to enter enable/privileged mode
    )
    ds.connect()                                   # Establish the SSH connection to the device
    _active_conns[key] = ds                        # Store in pool so future commands reuse this connection
    return ds


def _execute_command(conn_id: str, device_name: str, command: str) -> str:
    """
    Runs a single CLI command on the specified device and returns the raw output.
    Handles common SSH error conditions with user-friendly messages.
    """
    try:
        ds = _get_or_connect(conn_id, device_name)         # Get or open SSH connection to the device
        return ds.view(command.strip()) or "(No output returned)"  # Run the command; return raw CLI output
    except RuntimeError as e:
        return f"[ERROR] {e}"                              # Session expired or other known runtime error
    except Exception as e:
        msg = str(e).lower()
        if "timed out" in msg or "timeout" in msg:
            return f"[ERROR] Timed out connecting to {device_name}."       # Device unreachable or slow to respond
        if "authentication" in msg or "permission denied" in msg:
            return f"[ERROR] Authentication failed on {device_name}."      # Wrong username or password
        if "connection refused" in msg:
            return f"[ERROR] SSH refused on {device_name}."                # SSH not enabled or wrong port
        # For any other error, evict the dead connection from the pool so the next attempt reconnects fresh
        try:
            host = _resolve_host(conn_id, device_name)
            _active_conns.pop(f"{conn_id}:{host}", None)   # Remove stale connection from pool
        except Exception:
            pass
        return f"[ERROR] {e}"                              # Return the raw error message for unknown failures


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
def root():
    """
    Landing page: redirects to the run page if already logged in, otherwise to login.
    """
    if _get_creds(_get_conn_id()):
        return redirect(url_for("run"))    # Already have valid credentials — go straight to the command runner
    return redirect(url_for("login"))      # No credentials — send to login page


@app.route("/login", methods=["GET", "POST"])
def login():
    """
    GET:  Renders the login form.
    POST: Validates submitted credentials and device list, stores them in the cache, then redirects to /run.
    """
    conn_id = _get_conn_id()
    error = None

    if request.method == "POST":
        # Read form fields submitted by the user
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        enable_secret = (request.form.get("enable_secret") or "").strip() or None  # Optional — None if blank
        platform = (request.form.get("platform") or "").strip() or None            # Optional — None if blank

        # Parse the device list textarea: one device per line, format "NAME=IP" or "NAME IP" or "NAME: IP"
        raw_devices = request.form.get("devices") or ""
        devices = {}
        for line in raw_devices.strip().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue                            # Skip blank lines and comment lines
            parts = re.split(r"[=:\s]+", line, maxsplit=1)  # Split on =, :, or whitespace (first occurrence only)
            if len(parts) == 2:
                name, ip = parts[0].strip().upper(), parts[1].strip()  # Normalise device name to uppercase
                if name and ip:
                    devices[name] = ip              # Add to the device registry: {"SW1": "10.0.0.1", ...}

        if not username or not password:
            error = "Username and password are required."   # Validation: both fields must be filled
        else:
            _store_creds(conn_id, username, password, enable_secret, platform, devices)  # Cache credentials for this session
            return redirect(url_for("run"))         # Credentials stored — send to the command runner

    return render_template("login.html", error=error)  # Render login form (with error message if validation failed)


@app.route("/logout")
def logout():
    """
    Clears all cached credentials and SSH connections for the current session, then redirects to login.
    """
    conn_id = session.get("conn_id")
    if conn_id:
        _clear_creds(conn_id)   # Purge credentials and close all SSH connections for this session
    session.clear()             # Clear the session cookie (removes conn_id from the browser)
    return redirect(url_for("login"))


@app.route("/run")
def run():
    """
    Main command runner page. Redirects to login if the session has expired.
    Passes the list of registered device names to the template for the device dropdown.
    """
    conn_id = _get_conn_id()
    creds = _get_creds(conn_id)
    if not creds:
        return redirect(url_for("login"))          # Session expired — force re-login
    devices = list(creds.get("devices", {}).keys())  # Extract just the device names (e.g. ["SW1", "SW2"]) for the UI dropdown
    return render_template("run.html", devices=devices)


@app.route("/api/run", methods=["POST"])
def api_run():
    """
    API endpoint: receives a JSON body with 'device' and 'command', runs the command via SSH,
    and returns the raw CLI output as JSON. Called by the frontend JavaScript when the user submits a command.

    Expected request body: {"device": "SW1", "command": "show interfaces status"}
    Response:              {"output": "...", "device": "SW1", "command": "show interfaces status"}
    """
    conn_id = _get_conn_id()
    if not _get_creds(conn_id):
        return jsonify({"error": "Session expired. Please log in again."}), 401  # 401 Unauthorized — session has expired

    data = request.get_json(silent=True) or {}          # Parse JSON body; return empty dict if body is missing or malformed
    device_name = (data.get("device") or "").strip()    # Target device name or IP from the request
    command = (data.get("command") or "").strip()       # CLI command to run on the device

    if not device_name or not command:
        return jsonify({"error": "Device and command are required."}), 400  # 400 Bad Request — missing required fields

    output = _execute_command(conn_id, device_name, command)  # Run the command via SSH
    return jsonify({"output": output, "device": device_name, "command": command})  # Return the raw output to the browser


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8890, debug=True)
    # host="0.0.0.0"  — listen on all network interfaces (not just localhost), making it accessible on the LAN
    # port=8890       — the port this app runs on; access via http://<server-ip>:8890
    # debug=True      — enables auto-reload on code changes and detailed error pages; disable in production
