"""
MCP-powered Network Chat — Natural Language to Network CLI
Users log in with SSH credentials (optionally register device names). In chat they ask in plain English;
the app connects to any device by name, IP, or hostname using stored credentials.
DeepSeek AI (or optionally Anthropic Claude) interprets the request, picks the right CLI command,
runs it via SSH, and summarises the output conversationally.

Credentials are cached in memory for 24 hours.
Requires: flask (anthropic optional for local/dev; pyyaml, netmiko for device SSH)
Set DEEPSEEK_API_KEY or ANTHROPIC_API_KEY in your environment or in a .env file (pip install python-dotenv).
Omit both for local/dev (mock responses).
"""

# --- Standard library imports ---
import json      # Used to parse/serialise tool call arguments passed between the LLM and our code
import os        # Used to read environment variables (API keys, Flask secret key)
import re        # Used to parse the device list input (split on =, :, or whitespace)
import time      # Used to record when credentials were stored and calculate TTL expiry
import uuid      # Used to generate a unique session ID (conn_id) per browser session
from datetime import datetime     # Used to timestamp each command execution in the session log
from pathlib import Path          # Used to resolve file paths for .env loading and template folder
from typing import Optional       # Used for type hints on functions that may return None

# --- Flask web framework imports ---
from flask import Flask, Response, jsonify, redirect, render_template, request, session, url_for
# Flask           — core web application class
# Response        — used to build a plain-text file download response for the execution log export
# jsonify         — converts Python dicts to JSON HTTP responses
# redirect        — sends the browser to a different URL
# render_template — renders an HTML template file
# request         — access to incoming HTTP request data (form fields, JSON body, query params)
# session         — server-side session cookie (stores conn_id across requests)
# url_for         — generates URLs for named routes without hardcoding paths

# ---------------------------------------------------------------------------
# .env loading — must run before any os.environ reads so API keys are available
# ---------------------------------------------------------------------------

_SCRIPT_DIR = Path(__file__).resolve().parent  # Absolute path to the directory this script lives in

def _load_dotenv_plain():
    """
    Reads a .env file from the script directory or current working directory and sets
    environment variables for each KEY=VALUE line found. This runs before the dotenv
    library is imported so API keys are available even if python-dotenv is not installed.
    """
    for base in (_SCRIPT_DIR, Path.cwd()):         # Check both the script folder and wherever Python was launched from
        env_file = base / ".env"
        if not env_file.is_file():
            continue                                # No .env file in this location — skip
        try:
            with open(env_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip().replace("\r", "")           # Strip whitespace and Windows line endings
                    if not line or line.startswith("#"):
                        continue                                     # Skip blank lines and comments
                    if "=" in line:
                        key, _, value = line.partition("=")          # Split on the first = only
                        key = key.strip()
                        value = value.strip().strip("'\"").replace("\r", "").strip()  # Remove surrounding quotes
                        if key:
                            os.environ[key] = value                  # Set the environment variable
        except OSError:
            pass                                    # File unreadable — silently ignore

_load_dotenv_plain()   # First pass: load .env before attempting to import dotenv library
try:
    from dotenv import load_dotenv  # Use the proper dotenv library if it's installed (handles edge cases better)
    load_dotenv(_SCRIPT_DIR / ".env")
    load_dotenv()
except ImportError:
    pass                            # python-dotenv not installed — plain loader above is sufficient
_load_dotenv_plain()   # Second pass: re-run our plain loader so its values win if dotenv overwrote anything

# ---------------------------------------------------------------------------
# LLM provider setup — DeepSeek (preferred) or Anthropic Claude (fallback)
# ---------------------------------------------------------------------------

_deepseek_key = (os.environ.get("DEEPSEEK_API_KEY") or "").strip()  # Read DeepSeek API key from environment
_deepseek_client = None
try:
    from openai import OpenAI  # DeepSeek uses the OpenAI-compatible API, so we use the openai library
    if _deepseek_key:
        _deepseek_client = OpenAI(
            api_key=_deepseek_key,
            base_url="https://api.deepseek.com"  # Point the OpenAI client at DeepSeek's endpoint instead
        )
except ImportError:
    pass  # openai library not installed — DeepSeek unavailable

_anthropic_key = (os.environ.get("ANTHROPIC_API_KEY") or "").strip()  # Read Anthropic API key from environment
_anthropic = None
if _anthropic_key and not _deepseek_client:  # Only set up Anthropic if DeepSeek is NOT available (DeepSeek takes priority)
    try:
        import anthropic
        _anthropic = anthropic.Anthropic(api_key=_anthropic_key)  # Initialise the Anthropic client
    except ImportError:
        pass  # anthropic library not installed — Claude unavailable

# --- Import the SSH device session wrapper ---
try:
    from automation.device_session import DeviceSession  # Primary import path (inside automation package)
except ImportError:
    from device_session import DeviceSession             # Fallback for running directly from the project root

# ---------------------------------------------------------------------------
# Flask app setup
# ---------------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent  # Folder where this file lives — used to locate HTML templates
app = Flask(__name__, template_folder=str(BASE_DIR))  # Create Flask app; serve templates from same directory
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "mcp-change-me-in-prod")  # Signs session cookies; must be changed in production
app.permanent_session_lifetime = 86400  # Sessions persist for 24 hours before the browser cookie expires

CREDENTIAL_CACHE_TTL = 86400  # How long (seconds) credentials stay in memory after login — 24 hours

# ---------------------------------------------------------------------------
# In-memory data stores
# ---------------------------------------------------------------------------

# Credentials cache: conn_id -> {username, password, enable_secret, platform, devices, stored_at}
# Each browser session has its own isolated entry so multiple users can be logged in simultaneously
_cred_cache: dict[str, dict] = {}

# Active SSH connections: "conn_id:host" -> DeviceSession
# Connections are reused across chat turns to avoid reconnecting on every message
_active_conns: dict[str, DeviceSession] = {}

# Execution log: conn_id -> list of {device, command, output, at}
# Records every command run in the session — used for the per-device log view and export feature
_execution_log: dict[str, list[dict]] = {}

# ---------------------------------------------------------------------------
# MCP Tools definition — the functions the AI can call to talk to network devices
# ---------------------------------------------------------------------------

TOOLS = [
    {
        "name": "run_command",
        "description": (
            # Tells the AI when and how to use this tool.
            # 'run_command' is for a single CLI command on a single device.
            "Run any CLI show/display command on a network device and return the raw output. "
            "Use this for any request to check interfaces, routing, VLANs, neighbors, version, "
            "config, environment, counters, or anything that needs a show command. "
            "Always prefer a specific targeted command over show running-config unless the user "
            "explicitly asks for the full config. device_name can be a pre-registered name, an IP address, or a hostname."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "device_name": {
                    "type": "string",
                    "description": "Target device: registered name (e.g. SW1), IP address (e.g. 192.168.1.1), or hostname."
                },
                "command": {
                    "type": "string",
                    "description": "The full CLI command to run (e.g. 'show interfaces status', 'show ip route', 'show version')."
                }
            },
            "required": ["device_name", "command"]  # Both fields must be provided by the AI in every call
        }
    },
    {
        "name": "run_multiple_commands",
        "description": (
            # Used when the user asks about multiple devices or multiple pieces of info in one question.
            # e.g. "Show down interfaces on SW1 and SW2" triggers this tool with two tasks.
            "Run several CLI commands across one or more devices in a single call. "
            "Use when the user asks for multiple pieces of information at once, "
            "e.g. 'show me the interfaces and routing table on SW1'."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "tasks": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "device_name": {"type": "string"},
                            "command": {"type": "string"}
                        },
                        "required": ["device_name", "command"]
                    },
                    "description": "List of {device_name, command} pairs to execute."  # Each task = one device + one command
                }
            },
            "required": ["tasks"]
        }
    },
    {
        "name": "list_devices",
        # Lets the AI discover which devices are registered so it can use their names in run_command calls
        "description": "Return the list of registered devices and their IPs for this session.",
        "input_schema": {"type": "object", "properties": {}}  # No input required — just returns the device list
    }
]

# Convert the TOOLS list from Anthropic format to OpenAI/DeepSeek format.
# Anthropic uses {name, description, input_schema}; OpenAI uses {type, function: {name, description, parameters}}
TOOLS_OPENAI = [
    {"type": "function", "function": {"name": t["name"], "description": t["description"], "parameters": t["input_schema"]}}
    for t in TOOLS
]

# ---------------------------------------------------------------------------
# Session / connection ID helpers
# ---------------------------------------------------------------------------

def _get_conn_id() -> str:
    """
    Returns the unique connection ID for the current browser session.
    Creates and stores a new UUID in the session cookie if one doesn't exist yet.
    This ID is the key used for the credential cache, SSH connection pool, and execution log.
    """
    if "conn_id" not in session:
        session.permanent = True                   # Make session persist for the full permanent_session_lifetime
        session["conn_id"] = str(uuid.uuid4())     # Generate a new random unique ID for this browser session
    return session["conn_id"]

# ---------------------------------------------------------------------------
# Credential cache helpers
# ---------------------------------------------------------------------------

def _store_creds(conn_id: str, username: str, password: str,
                 enable_secret: Optional[str], platform: Optional[str],
                 devices: dict) -> None:
    """
    Saves the user's SSH credentials and device list into the in-memory cache under their conn_id.
    All subsequent commands in this session will use these credentials.
    """
    _cred_cache[conn_id] = {
        "username": username,           # SSH username for logging into network devices
        "password": password,           # SSH password
        "enable_secret": enable_secret, # Optional enable/privileged mode password (Cisco etc.)
        "platform": platform,           # Optional Netmiko platform string (e.g. cisco_ios, arista_eos)
        "devices": devices,             # Dict mapping device names to IPs: {"SW1": "10.0.0.1", ...}
        "stored_at": time.time(),       # Timestamp used to calculate TTL and session expiry countdown
    }

def _get_creds(conn_id: str) -> Optional[dict]:
    """
    Retrieves the cached credentials for this session.
    Returns None and cleans up if the credentials have expired past the 24-hour TTL.
    """
    entry = _cred_cache.get(conn_id)
    if not entry:
        return None                    # No session found — not logged in
    if (time.time() - entry["stored_at"]) > CREDENTIAL_CACHE_TTL:
        del _cred_cache[conn_id]       # Expire the credential entry
        _evict_connections(conn_id)    # Close and remove all SSH connections for this session
        return None
    return entry                       # Valid credentials within TTL — return them

def _clear_creds(conn_id: str) -> None:
    """
    Removes credentials, execution log, and all SSH connections for this session.
    Called on explicit logout to ensure a full clean teardown.
    """
    _cred_cache.pop(conn_id, None)         # Delete credential cache entry
    _execution_log.pop(conn_id, None)      # Delete command history for this session
    _evict_connections(conn_id)            # Close and remove all active SSH connections

def _evict_connections(conn_id: str) -> None:
    """
    Closes and removes all active SSH connections belonging to a given session.
    Used both on logout and when credentials expire.
    """
    stale = [k for k in _active_conns if k.startswith(conn_id + ":")]  # Find all connections for this session
    for k in stale:
        try:
            _active_conns[k].disconnect()  # Gracefully close the SSH connection to the device
        except Exception:
            pass                           # Ignore errors — device may already be unreachable
        del _active_conns[k]               # Remove from the connection pool

def _cache_expires_at(conn_id: str) -> Optional[str]:
    """
    Returns a human-readable string showing how long until the session expires (e.g. '23h', '45m').
    Returns None if the session doesn't exist or has already expired.
    Displayed in the UI as a session countdown badge.
    """
    entry = _cred_cache.get(conn_id)
    if not entry:
        return None
    expiry_ts = entry["stored_at"] + CREDENTIAL_CACHE_TTL  # Calculate exact expiry timestamp
    if time.time() > expiry_ts:
        return None                        # Already expired
    remaining = int(expiry_ts - time.time())  # Seconds remaining until expiry
    if remaining >= 3600:
        return f"{remaining // 3600}h"     # Show hours if more than 60 minutes remain
    if remaining >= 60:
        return f"{remaining // 60}m"       # Show minutes if more than 1 minute remains
    return "1m"                            # Show "1m" for anything under a minute

def _cleanup_stale_caches() -> None:
    """
    Evicts all expired credential cache entries across all sessions.
    Called at the start of each chat API request to prevent unbounded memory growth.
    """
    now = time.time()
    for cid in [c for c, e in list(_cred_cache.items())
                if (now - e["stored_at"]) > CREDENTIAL_CACHE_TTL]:  # Find all sessions past their TTL
        _clear_creds(cid)  # Clean up credentials, log, and SSH connections for each expired session

# ---------------------------------------------------------------------------
# SSH execution helpers — the actual implementations behind each MCP tool
# ---------------------------------------------------------------------------

def _resolve_host(conn_id: str, device_name: str) -> str:
    """
    Resolves a device name (e.g. 'SW1') to an IP address using the session's device registry.
    If the name isn't registered, it's returned unchanged (treated as a direct IP or hostname).
    Raises RuntimeError if the session has expired.
    """
    creds = _get_creds(conn_id)
    if not creds:
        raise RuntimeError("Credential cache expired. Please log in again.")
    devices = creds.get("devices", {})
    for name, ip in devices.items():
        if name.upper() == device_name.upper():  # Case-insensitive match so SW1 == sw1
            return ip
    return device_name.strip()  # Not in registry — assume caller passed an IP or hostname directly

def _get_or_connect(conn_id: str, device_name: str) -> DeviceSession:
    """
    Returns an active SSH session to the target device.
    Reuses an existing connection from the pool if available (avoids reconnecting on every command).
    Creates and caches a new connection if none exists.
    """
    host = _resolve_host(conn_id, device_name)  # Resolve device name to its IP/hostname
    key = f"{conn_id}:{host}"                   # Unique key: session ID + host ensures per-user isolation
    if key in _active_conns:
        return _active_conns[key]               # Connection already open — reuse it

    creds = _get_creds(conn_id)
    if not creds:
        raise RuntimeError("Credential cache expired. Please log in again.")

    # Open a new SSH connection to the device using the stored credentials
    ds = DeviceSession(
        host=host,
        username=creds["username"],
        password=creds["password"],
        platform=creds.get("platform"),          # Tells Netmiko which CLI dialect to expect
        enable_secret=creds.get("enable_secret"),# Used to escalate to privileged/enable mode if needed
    )
    ds.connect()                                 # Establish the SSH session
    _active_conns[key] = ds                      # Cache the connection for reuse in subsequent commands
    return ds

def _execute_run_command(conn_id: str, device_name: str, command: str) -> str:
    """
    Executes a single CLI command on a device and returns the raw text output.
    Translates common SSH exceptions into clear error messages for the AI to relay to the user.
    """
    try:
        ds = _get_or_connect(conn_id, device_name)         # Get or create SSH connection
        output = ds.view(command)                          # Run the show command; returns raw CLI text
        return output or "(No output returned)"            # Handle devices that return empty output
    except RuntimeError as e:
        return f"[ERROR] {e}"                              # Session expired or other known error
    except Exception as e:
        msg = str(e).lower()
        if "timed out" in msg or "timeout" in msg:
            return f"[ERROR] Timed out connecting to {device_name}. Check that the device is reachable."
        if "authentication" in msg or "permission denied" in msg:
            return f"[ERROR] Authentication failed on {device_name}. Check credentials."
        if "connection refused" in msg:
            return f"[ERROR] SSH refused on {device_name}. Ensure SSH is enabled."
        # Unknown error — remove the potentially dead connection from the pool so the next call reconnects fresh
        try:
            host = _resolve_host(conn_id, device_name)
            _active_conns.pop(f"{conn_id}:{host}", None)   # Evict stale connection
        except Exception:
            pass
        return f"[ERROR] {e}"

def _execute_tool(conn_id: str, tool_name: str, tool_input: dict) -> str:
    """
    Dispatches an AI tool call to the appropriate SSH execution function.
    This is the bridge between what the AI requests and what actually runs on the network.
    """
    if tool_name == "run_command":
        # Single device, single command — simplest case
        return _execute_run_command(
            conn_id, tool_input["device_name"], tool_input["command"]
        )
    elif tool_name == "run_multiple_commands":
        # Multiple device/command pairs — run each one and concatenate results
        results = []
        for task in tool_input.get("tasks", []):
            output = _execute_run_command(conn_id, task["device_name"], task["command"])
            results.append(f"--- {task['device_name']} | {task['command']} ---\n{output}")  # Label each result block
        return "\n\n".join(results)  # Return all results as one combined string for the AI to summarise
    elif tool_name == "list_devices":
        # Returns the registered device inventory so the AI knows what names are available
        creds = _get_creds(conn_id)
        if not creds:
            return "Not logged in."
        devices = creds.get("devices", {})
        if not devices:
            return (
                # Tell the AI it can still use raw IPs/hostnames even without registered devices
                "No devices pre-registered. The user can specify any device by IP or hostname in their question, "
                "e.g. 'show interfaces on 192.168.1.1' or 'show version on router1'. Use that IP or hostname as device_name."
            )
        lines = [f"  {name} → {ip}" for name, ip in devices.items()]
        return "Registered devices:\n" + "\n".join(lines)
    return f"[ERROR] Unknown tool: {tool_name}"  # Safety fallback for unexpected tool names

# ---------------------------------------------------------------------------
# System prompt — the AI's operating instructions
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are a network operations assistant. You help network engineers by running
CLI commands on their devices and explaining the output clearly.

Supported device types: Cisco IOS/NX-OS, Arista EOS, Palo Alto PAN-OS, and Check Point Gaia.
Use the correct CLI syntax for the device (e.g. Palo Alto and Check Point have different show
commands than Cisco). If the user did not specify platform, use common show commands; the app
may auto-detect or the user will have selected a platform at login.

The user has stored SSH credentials; they may or may not have pre-registered devices. When they
ask about a device, use the identifier they give: a registered name (e.g. SW1), an IP address
(e.g. 192.168.1.1), or a hostname. Pass that exactly as device_name to run_command — the system
will connect with the stored credentials. Use list_devices to see any pre-registered names; if
none, the user can still use any IP or hostname in their question.

Choose the most specific command that answers the question — do not run full config dumps when
a targeted show command will do. After getting tool output, summarise the key findings in plain
English. Be concise — one paragraph is usually enough unless the user asks for detail.

If there is an error connecting, report it clearly and suggest what to check.
Do not make up output — always call the tool first."""
# This prompt shapes how the AI behaves: it enforces targeted commands, plain-English summaries,
# and prevents the AI from fabricating device output without actually running a command.

# ---------------------------------------------------------------------------
# DeepSeek agentic loop
# ---------------------------------------------------------------------------

def _run_deepseek_loop(conn_id: str, user_message: str, chat_history: list) -> dict:
    """
    Sends the user's message to DeepSeek with tool definitions. If DeepSeek calls a tool,
    the result is fed back and the loop continues until DeepSeek gives a final text response
    or the 10-round safety limit is reached.
    Returns: {"response": str, "tool_calls": [{device, command, output}, ...]}
    """
    messages = [*chat_history, {"role": "user", "content": user_message}]  # Append new message to conversation history
    tool_calls_log = []  # Track every command executed this turn for the execution log

    for _ in range(10):  # Safety cap: max 10 rounds of tool calls to prevent infinite loops
        kwargs = {
            "model": "deepseek-chat",                                      # DeepSeek model to use
            "messages": [{"role": "system", "content": SYSTEM_PROMPT}] + messages,  # System prompt + full conversation
            "max_tokens": 2048,                                            # Cap on response length
            "tools": TOOLS_OPENAI,                                         # Available tools in OpenAI format
        }
        response = _deepseek_client.chat.completions.create(**kwargs)      # Send request to DeepSeek API
        msg = response.choices[0].message                                  # Extract the first (and only) response message
        tool_calls = getattr(msg, "tool_calls", None) or []                # Get tool calls if any were requested

        if not tool_calls:
            # No tool calls — DeepSeek has produced its final answer
            return {"response": (msg.content or "").strip(), "tool_calls": tool_calls_log}

        # Build a serialisable assistant turn (avoids issues with non-JSON-serialisable response objects)
        assistant_tool_calls = []
        for tc in tool_calls:
            name = tc.function.name if hasattr(tc.function, "name") else tc.function.get("name")
            args_raw = tc.function.arguments if hasattr(tc.function, "arguments") else tc.function.get("arguments", "{}")
            tc_id = tc.id if hasattr(tc, "id") else tc.get("id")
            assistant_tool_calls.append({
                "id": tc_id,
                "type": "function",
                "function": {
                    "name": name,
                    "arguments": args_raw if isinstance(args_raw, str) else json.dumps(args_raw)  # Ensure arguments are a JSON string
                }
            })
        messages.append({"role": "assistant", "content": msg.content or None, "tool_calls": assistant_tool_calls})

        # Execute each requested tool and feed the results back into the message history
        for tc in tool_calls:
            name = tc.function.name if hasattr(tc.function, "name") else tc.function.get("name")
            args_raw = tc.function.arguments if hasattr(tc.function, "arguments") else tc.function.get("arguments", "{}")
            try:
                args = json.loads(args_raw) if isinstance(args_raw, str) else args_raw  # Parse JSON arguments string
            except (json.JSONDecodeError, TypeError):
                args = {}                          # Fallback to empty args if parsing fails
            output = _execute_tool(conn_id, name, args)  # Actually run the CLI command on the device

            # Log the command for the execution history panel in the UI
            if name == "run_command":
                tool_calls_log.append({"device": args.get("device_name", "?"), "command": args.get("command", "?"), "output": output})
            elif name == "run_multiple_commands":
                for task in args.get("tasks", []):
                    tool_calls_log.append({"device": task.get("device_name", "?"), "command": task.get("command", "?"), "output": output})

            tc_id = tc.id if hasattr(tc, "id") else tc.get("id")
            messages.append({"role": "tool", "tool_call_id": tc_id, "content": output})  # Feed SSH output back to DeepSeek

    return {"response": "Reached maximum tool call limit.", "tool_calls": tool_calls_log}  # Safety fallback if loop limit hit


# ---------------------------------------------------------------------------
# LLM dispatcher — chooses DeepSeek, Claude, or local mock
# ---------------------------------------------------------------------------

def _run_llm_loop(conn_id: str, user_message: str, chat_history: list) -> dict:
    """
    Entry point for all chat requests. Routes to the correct LLM backend depending on
    which API key is configured. Falls back to a descriptive local mode message if no key is set.
    """
    if _deepseek_client:
        return _run_deepseek_loop(conn_id, user_message, chat_history)  # DeepSeek takes priority
    if _anthropic:
        return _run_claude_loop(conn_id, user_message, chat_history)    # Claude is the fallback
    # Neither LLM is available — build a helpful error message explaining why
    reason = []
    if not _deepseek_key and not _anthropic_key:
        reason.append("No API key set (put DEEPSEEK_API_KEY in .env or env).")
    elif _deepseek_key and not _deepseek_client:
        reason.append("DEEPSEEK_API_KEY is set but the DeepSeek client could not start. Install: pip install openai")
    elif _anthropic_key and not _anthropic:
        reason.append("ANTHROPIC_API_KEY is set but the Anthropic client could not start. Install: pip install anthropic")
    else:
        reason.append("LLM not available.")
    return {
        "response": (
            "Running in **local mode** — " + " ".join(reason) + " "
            "Restart the app after fixing. "
            f"You said: \"{user_message}\""
        ),
        "tool_calls": [],
    }


# ---------------------------------------------------------------------------
# Anthropic Claude agentic loop
# ---------------------------------------------------------------------------

def _run_claude_loop(conn_id: str, user_message: str, chat_history: list) -> dict:
    """
    Sends the user's message to Claude with tool definitions. If Claude calls a tool,
    the result is fed back and the loop continues until Claude gives a final text response
    or the 10-round safety limit is reached.
    Returns: {"response": str, "tool_calls": [{device, command, output}, ...]}
    """
    messages = chat_history + [{"role": "user", "content": user_message}]  # Full conversation context
    tool_calls_log = []  # Tracks every command run this turn for the execution log

    for _ in range(10):  # Safety cap: max 10 rounds of tool calls
        response = _anthropic.messages.create(
            model="claude-sonnet-4-20250514",   # Claude model to use for this request
            max_tokens=2048,                    # Maximum length of Claude's response
            system=SYSTEM_PROMPT,               # Inject the system prompt with operating instructions
            tools=TOOLS,                        # Available tools in Anthropic format
            messages=messages,                  # Full conversation history so Claude has context
        )

        # Separate text blocks from tool use blocks in the response
        text_parts = []
        tool_use_blocks = []
        for block in response.content:
            if block.type == "text":
                text_parts.append(block.text)       # Collect text segments (the final summary)
            elif block.type == "tool_use":
                tool_use_blocks.append(block)        # Collect tool call requests

        # If Claude stopped without calling any tools, this is the final answer
        if response.stop_reason == "end_turn" or not tool_use_blocks:
            return {
                "response": "\n".join(text_parts).strip(),
                "tool_calls": tool_calls_log,
            }

        # Append Claude's response (including tool call requests) to the conversation history
        messages.append({"role": "assistant", "content": response.content})
        tool_results = []

        # Execute each tool call and collect the results to feed back to Claude
        for block in tool_use_blocks:
            output = _execute_tool(conn_id, block.name, block.input)  # Run the actual CLI command on the device

            # Log the command for the execution history panel
            if block.name == "run_command":
                tool_calls_log.append({
                    "device": block.input.get("device_name", "?"),
                    "command": block.input.get("command", "?"),
                    "output": output,
                })
            elif block.name == "run_multiple_commands":
                for task in block.input.get("tasks", []):
                    tool_calls_log.append({
                        "device": task.get("device_name", "?"),
                        "command": task.get("command", "?"),
                        "output": output,
                    })

            tool_results.append({
                "type": "tool_result",
                "tool_use_id": block.id,   # Must match the ID from Claude's tool_use block
                "content": output,         # The raw SSH output returned to Claude for summarisation
            })

        messages.append({"role": "user", "content": tool_results})  # Feed all tool results back to Claude as a user turn

    return {"response": "Reached maximum tool call limit.", "tool_calls": tool_calls_log}


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/", methods=["GET"])
def root():
    """
    Landing page: redirects to the chat page if already logged in, otherwise to the login page.
    """
    conn_id = _get_conn_id()
    if _get_creds(conn_id):
        return redirect(url_for("chat"))   # Already authenticated — go to chat
    return redirect(url_for("login"))      # Not authenticated — go to login


@app.route("/login", methods=["GET", "POST"])
def login():
    """
    GET:  Renders the login form with any existing session expiry shown.
    POST: Validates credentials, parses the device list, stores everything in the cache, then redirects to chat.
    """
    conn_id = _get_conn_id()
    error = None

    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        enable_secret = (request.form.get("enable_secret") or "").strip() or None  # Optional — None if left blank
        platform = (request.form.get("platform") or "").strip() or None            # Optional — None if left blank

        # Parse device list: one entry per line, supports NAME=IP, NAME:IP, or NAME IP formats
        raw_devices = request.form.get("devices") or ""
        devices = {}
        for line in raw_devices.strip().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue                                         # Skip blank lines and comments
            parts = re.split(r'[=:\s]+', line, maxsplit=1)      # Split on first =, :, or whitespace
            if len(parts) == 2:
                name, ip = parts[0].strip().upper(), parts[1].strip()  # Uppercase device names for consistency
                if name and ip:
                    devices[name] = ip                           # Add to registry: {"SW1": "10.0.0.1"}

        if not username or not password:
            error = "Username and password are required."
        else:
            _store_creds(conn_id, username, password, enable_secret, platform, devices)  # Store credentials in cache
            return redirect(url_for("chat"))

    return render_template("mcp_login.html", error=error,
                           expires_at=_cache_expires_at(conn_id))  # Pass expiry so UI can show session status


@app.route("/logout")
def logout():
    """
    Clears all session data (credentials, execution log, SSH connections) and redirects to login.
    """
    conn_id = session.get("conn_id")
    if conn_id:
        _clear_creds(conn_id)  # Full teardown: credentials + log + SSH connections
    session.clear()            # Clear the browser session cookie
    return redirect(url_for("login"))


@app.route("/chat")
def chat():
    """
    Main chat interface. Redirects to login if session has expired.
    Passes device names, session expiry, and username to the template for display.
    """
    conn_id = _get_conn_id()
    creds = _get_creds(conn_id)
    if not creds:
        return redirect(url_for("login"))               # Session expired — force re-login
    expires_at = _cache_expires_at(conn_id)             # Session countdown for the UI badge
    devices = list(creds.get("devices", {}).keys())     # Device names for the sidebar device list
    return render_template("mcp_chat.html",
                           devices=devices,
                           expires_at=expires_at,
                           username=creds.get("username", ""))


@app.route("/api/chat", methods=["POST"])
def api_chat():
    """
    Main chat API endpoint. Receives a user message and conversation history,
    runs the LLM loop (which may execute SSH commands), and returns the AI's response.

    Request body: {"message": "show down interfaces on SW1", "history": [...]}
    Response:     {"response": "...", "tool_calls": [...], "expires_at": "23h"}
    """
    _cleanup_stale_caches()    # Evict expired sessions before processing to keep memory clean
    conn_id = _get_conn_id()
    creds = _get_creds(conn_id)
    if not creds:
        return jsonify({"error": "Session expired. Please log in again."}), 401

    data = request.get_json(silent=True) or {}
    user_message = (data.get("message") or "").strip()
    history = data.get("history") or []                # Full conversation history sent by the frontend

    if not user_message:
        return jsonify({"error": "Empty message."}), 400

    # Sanitise history: keep last 20 turns, only valid user/assistant messages with non-empty content
    clean_history = []
    for msg in history[-20:]:
        if msg.get("role") in ("user", "assistant") and msg.get("content"):
            clean_history.append({"role": msg["role"], "content": str(msg["content"])})

    try:
        result = _run_llm_loop(conn_id, user_message, clean_history)  # Run the full AI + tool execution loop

        # Append executed commands to the persistent session execution log
        log = _execution_log.setdefault(conn_id, [])
        for tc in result.get("tool_calls") or []:
            log.append({
                "device": tc.get("device", "?"),
                "command": tc.get("command", "?"),
                "output": tc.get("output", ""),
                "at": datetime.now().isoformat(),  # ISO timestamp for when the command was run
            })
        return jsonify({
            "response": result["response"],        # The AI's plain-English summary to show in chat
            "tool_calls": result["tool_calls"],    # The raw commands and outputs for the detail panel
            "expires_at": _cache_expires_at(conn_id),  # Refresh the session countdown in the UI
        })
    except Exception as e:
        if type(e).__name__ == "AuthenticationError":
            return jsonify({"error": "Anthropic API key is invalid. Check ANTHROPIC_API_KEY."}), 500
        return jsonify({"error": f"Unexpected error: {e}"}), 500


@app.route("/api/session")
def api_session():
    """
    Returns the current session expiry string (e.g. '23h').
    Polled periodically by the frontend to keep the session countdown badge up to date.
    """
    conn_id = _get_conn_id()
    if not _get_creds(conn_id):
        return jsonify({"error": "Not logged in"}), 401
    return jsonify({"expires_at": _cache_expires_at(conn_id)})


@app.route("/api/devices")
def api_devices():
    """
    Returns the full device registry for this session (name → IP mapping).
    Used by the frontend to display the registered device list.
    """
    conn_id = _get_conn_id()
    creds = _get_creds(conn_id)
    if not creds:
        return jsonify({"error": "Not logged in"}), 401
    return jsonify({"devices": creds.get("devices", {})})


@app.route("/api/devices_accessed")
def api_devices_accessed():
    """
    Returns a sorted list of device names that the user has actually run commands on this session.
    Used by the sidebar to show which devices have execution history available.
    """
    conn_id = _get_conn_id()
    if not _get_creds(conn_id):
        return jsonify({"error": "Not logged in"}), 401
    log = _execution_log.get(conn_id, [])
    devices = sorted(set(e["device"] for e in log if e.get("device")))  # Deduplicate and sort alphabetically
    return jsonify({"devices": devices})


@app.route("/api/device_log")
def api_device_log():
    """
    Returns the full execution log for a specific device: commands run, raw output, and timestamps.
    Used to populate the device log panel in the UI when the user clicks a device in the sidebar.

    Query param: ?device=SW1
    """
    conn_id = _get_conn_id()
    if not _get_creds(conn_id):
        return jsonify({"error": "Not logged in"}), 401
    device = (request.args.get("device") or "").strip()
    if not device:
        return jsonify({"error": "device query param required"}), 400
    log = _execution_log.get(conn_id, [])
    entries = [{"command": e["command"], "output": e["output"], "at": e["at"]}
               for e in log if e.get("device") == device]  # Filter log to only this device's entries
    return jsonify({"device": device, "entries": entries})


@app.route("/api/device_log/download")
def api_device_log_download():
    """
    Downloads the execution log for a specific device as a plain text file.
    Each entry shows the timestamp, command run, and raw output, separated by a divider.
    Useful for saving evidence during an incident or sharing with the team.

    Query param: ?device=SW1
    """
    conn_id = _get_conn_id()
    if not _get_creds(conn_id):
        return jsonify({"error": "Not logged in"}), 401
    device = (request.args.get("device") or "").strip()
    if not device:
        return jsonify({"error": "device query param required"}), 400
    log = _execution_log.get(conn_id, [])
    entries = [e for e in log if e.get("device") == device]
    lines = []
    for e in entries:
        lines.append(f"# {e.get('at', '')}")           # Timestamp header for each command block
        lines.append(f"Command: {e.get('command', '')}")
        lines.append("")
        lines.append(e.get("output", ""))              # Raw CLI output
        lines.append("")
        lines.append("-" * 60)                         # Divider between entries
        lines.append("")
    body = "\n".join(lines)
    safe_name = re.sub(r"[^\w\-.]", "_", device)[:64]  # Sanitise device name for use in the filename
    return Response(body, mimetype="text/plain", headers={
        "Content-Disposition": f"attachment; filename={safe_name}_execution_log.txt"  # Triggers browser file download
    })


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    env_path = _SCRIPT_DIR / ".env"
    print(f"[NetOps] .env path: {env_path} (exists: {env_path.is_file()})")          # Confirm whether .env file was found
    print(f"[NetOps] DEEPSEEK_API_KEY: {'set' if _deepseek_key else 'NOT SET'}")      # Confirm API key status on startup
    if _deepseek_key and not _deepseek_client:
        print("[NetOps] WARNING: Key set but DeepSeek client is None. Install: pip install openai")
    print(f"[NetOps] LLM: {'DeepSeek' if _deepseek_client else 'Anthropic' if _anthropic else 'local mode'}")  # Show which LLM is active
    app.run(host="0.0.0.0", port=8889, debug=True)
    # host="0.0.0.0"  — listen on all interfaces so the app is reachable on the LAN (not just localhost)
    # port=8889       — this app runs on 8889; the no-AI version runs on 8890 to avoid conflict
    # debug=True      — enables auto-reload and detailed error pages; must be disabled in production
